﻿using System;
using System.Media;
using System.Windows.Forms;
using System.Drawing;

namespace MathQuiz
{
    public partial class Form1 : Form
    {
        // Генератор случайных чисел
        Random randomizer = new Random();

        // Сложение
        int addend1, addend2;
        // Вычитание
        int minuend, subtrahend;
        // Умножение
        int multiplicand, multiplier;
        // Деление
        int dividend, divisor;

        // Оставшееся время (секунды)
        int timeLeft;

        public Form1()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Заполняет тест случайными задачами и запускает таймер.
        /// </summary>
        public void StartTheQuiz()
        {
            // Сложение
            addend1 = randomizer.Next(51);
            addend2 = randomizer.Next(51);
            plusLeftLabel.Text = addend1.ToString();
            plusRightLabel.Text = addend2.ToString();
            sum.Value = 0;

            // Вычитание (результат не отрицательный)
            minuend = randomizer.Next(1, 101);
            subtrahend = randomizer.Next(1, minuend);
            minusLeftLabel.Text = minuend.ToString();
            minusRightLabel.Text = subtrahend.ToString();
            difference.Value = 0;

            // Умножение
            multiplicand = randomizer.Next(2, 11);
            multiplier = randomizer.Next(2, 11);
            timesLeftLabel.Text = multiplicand.ToString();
            timesRightLabel.Text = multiplier.ToString();
            product.Value = 0;

            // Деление (без остатка)
            divisor = randomizer.Next(2, 11);
            int temporaryQuotient = randomizer.Next(2, 11);
            dividend = divisor * temporaryQuotient;
            dividedLeftLabel.Text = dividend.ToString();
            dividedRightLabel.Text = divisor.ToString();
            quotient.Value = 0;

            // Таймер
            timeLeft = 30;
            timeLabel.Text = "30 seconds";
            timeLabel.BackColor = SystemColors.Control;
            timer1.Start();
        }

        /// <summary>
        /// Проверяет все четыре ответа.
        /// </summary>
        private bool CheckTheAnswer()
        {
            return (addend1 + addend2 == sum.Value)
                && (minuend - subtrahend == difference.Value)
                && (multiplicand * multiplier == product.Value)
                && (dividend / divisor == quotient.Value);
        }

        private void startButton_Click(object sender, EventArgs e)
        {
            StartTheQuiz();
            startButton.Enabled = false;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (CheckTheAnswer())
            {
                // Все ответы верны
                timer1.Stop();
                timeLabel.BackColor = SystemColors.Control;
                MessageBox.Show("You got all of the answers right!", "Congratulations!");
                startButton.Enabled = true;
            }
            else if (timeLeft > 0)
            {
                timeLeft--;
                timeLabel.Text = timeLeft + " seconds";

                // Последние 5 секунд: красный фон
                if (timeLeft <= 5)
                {
                    timeLabel.BackColor = Color.Red;
                }
            }
            else
            {
                // Время вышло
                timer1.Stop();
                timeLabel.Text = "Time's up!";
                SystemSounds.Hand.Play();
                MessageBox.Show("You didn't finish in time.", "Sorry!");
                sum.Value = addend1 + addend2;
                difference.Value = minuend - subtrahend;
                product.Value = multiplicand * multiplier;
                quotient.Value = dividend / divisor;
                startButton.Enabled = true;
            }
        }

        /// <summary>
        /// При входе в поле выделяет текущее значение, чтобы его не нужно было стирать.
        /// </summary>
        private void answer_Enter(object sender, EventArgs e)
        {
            NumericUpDown answerBox = sender as NumericUpDown;

            if (answerBox != null)
            {
                int lengthOfAnswer = answerBox.Value.ToString().Length;
                answerBox.Select(0, lengthOfAnswer);
            }
        }

        /// <summary>
        /// Звук, когда ответ в поле верный (во время теста).
        /// </summary>
        private void answer_ValueChanged(object sender, EventArgs e)
        {
            if (!timer1.Enabled) return;

            if (sender == sum && sum.Value == addend1 + addend2
                || sender == difference && difference.Value == minuend - subtrahend
                || sender == product && product.Value == multiplicand * multiplier
                || sender == quotient && quotient.Value == dividend / divisor)
            {
                SystemSounds.Asterisk.Play();
            }
        }
    }
}
