﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("MathQuiz")]
[assembly: AssemblyProduct("MathQuiz")]
[assembly: ComVisible(false)]
[assembly: Guid("b7c1f2a4-3d5e-4f60-9a1b-2c3d4e5f6a7b")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
